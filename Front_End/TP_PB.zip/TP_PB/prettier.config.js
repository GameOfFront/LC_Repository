/* eslint-disable no-undef */
module.exports = {
    semi: false,
    trailingComma: 'all',
    singleQuote: true,
    printWidth: 80,
    tabWidth: 3,
 }