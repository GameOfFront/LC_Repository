import { Nav } from "./components/NavBar/index.jsx";

export const App = () => {
  return (
    <>
      <Nav />
    </>
  );
};
