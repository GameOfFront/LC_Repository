package model;

import lombok.Data;

@Data
public class Usuario {
    private int id;
    private String nome;
    private String senha;
}
