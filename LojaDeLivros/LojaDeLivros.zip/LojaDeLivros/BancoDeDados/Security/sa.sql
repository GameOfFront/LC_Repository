﻿CREATE LOGIN [sa]
    WITH PASSWORD = N'wyiww|hupsj:h4g4uU,iunuhmsFT7_&#$!~<vixsJlo{kd.E';


GO
ALTER LOGIN [sa] DISABLE;

