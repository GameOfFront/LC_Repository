// inclusao.cshtml.cs
using LojaDeLivros.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LojaDeLivros.Pages
{
    public class InclusaoModel : PageModel
    {
        private readonly ServicoBancoDeDados _servicoBancoDeDados;

        public InclusaoModel(ServicoBancoDeDados servicoBancoDeDados)
        {
            _servicoBancoDeDados = servicoBancoDeDados;
        }

        [BindProperty]
        public Produto NovoProduto { get; set; }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _servicoBancoDeDados.AdicionarProduto(NovoProduto);

            return RedirectToPage("./Listagem");
        }
    }
}
