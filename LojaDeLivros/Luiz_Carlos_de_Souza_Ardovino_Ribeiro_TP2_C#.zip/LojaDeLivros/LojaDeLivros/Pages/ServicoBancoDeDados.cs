﻿using System.Collections.Generic;
using System.Linq;
using LojaDeLivros.Models;

namespace LojaDeLivros.Pages
{
    public class ServicoBancoDeDados
    {
        private List<Produto> _listaDeProdutos;

        public ServicoBancoDeDados()
        {
            _listaDeProdutos = new List<Produto>
            {
                new Produto { Id = 1, Nome = "Livro 1", Preco = 19.99 },
                new Produto { Id = 2, Nome = "Livro 2", Preco = 29.99 },
                new Produto { Id = 3, Nome = "Livro 3", Preco = 14.99 },
                // Adicione mais produtos conforme necessário
            };
        }

        public List<Produto> ObterTodosOsProdutos()
        {
            return _listaDeProdutos;
        }

        public Produto ObterProdutoPorId(int id)
        {
            return _listaDeProdutos.FirstOrDefault(p => p.Id == id);
        }

        public void AdicionarProduto(Produto novoProduto)
        {
            if (_listaDeProdutos.Any())
            {
                novoProduto.Id = _listaDeProdutos.Max(p => p.Id) + 1;
            }
            else
            {
                novoProduto.Id = 1; // Se a lista estiver vazia, comece com o ID 1
            }

            _listaDeProdutos.Add(novoProduto);
        }

        public void AtualizarProduto(Produto produtoAtualizado)
        {
            var produtoExistente = _listaDeProdutos.FirstOrDefault(p => p.Id == produtoAtualizado.Id);
            if (produtoExistente != null)
            {
                produtoExistente.Nome = produtoAtualizado.Nome;
                produtoExistente.Preco = produtoAtualizado.Preco;
                // Atualize outras propriedades conforme necessário
            }
        }

        public void ExcluirProduto(int id)
        {
            var produtoExistente = _listaDeProdutos.FirstOrDefault(p => p.Id == id);
            if (produtoExistente != null)
            {
                _listaDeProdutos.Remove(produtoExistente);
            }
        }
    }
}