﻿using System;
using System.ComponentModel.DataAnnotations;

namespace LojaDeLivros.Models
{
    public class Produto
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O campo Nome é obrigatório.")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "O campo Ativo é obrigatório.")]
        public bool Ativo { get; set; }

        [Required(ErrorMessage = "O campo Preço é obrigatório.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "O preço deve ser maior que zero.")]
        public double Preco { get; set; }

        [Required(ErrorMessage = "O campo Data de Criação é obrigatório.")]
        [DataType(DataType.DateTime, ErrorMessage = "Formato de data inválido.")]
        public DateTime DataCriacao { get; set; }

        // Adicione mais propriedades conforme necessário para representar seus produtos ou serviços
    }
}
